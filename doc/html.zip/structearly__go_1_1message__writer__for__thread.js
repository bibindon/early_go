var structearly__go_1_1message__writer__for__thread =
[
    [ "message_writer_for_thread", "structearly__go_1_1message__writer__for__thread.html#aa98547a615fb05621949ee50dcaea1c4", null ],
    [ "~message_writer_for_thread", "structearly__go_1_1message__writer__for__thread.html#a62fc5237641b1dffa849ba0780d6f50b", null ],
    [ "add_text", "structearly__go_1_1message__writer__for__thread.html#a2c79c271f7a9de8e7e40ad2e9cc25b4b", null ],
    [ "write_one_character", "structearly__go_1_1message__writer__for__thread.html#ac75d7fe6d04620a2b9c08574e287a876", null ],
    [ "canvas_size_", "structearly__go_1_1message__writer__for__thread.html#a5c2e205241c717f209c04b3cfda74cac", null ],
    [ "character_index_", "structearly__go_1_1message__writer__for__thread.html#a29690749486fed9095bb86344dfe157d", null ],
    [ "color_", "structearly__go_1_1message__writer__for__thread.html#a3212274dd148cd9428682bd3a7a01964", null ],
    [ "font_height_sum_", "structearly__go_1_1message__writer__for__thread.html#aee73a54a39707b7118db75e8791c5a63", null ],
    [ "font_width_sum_", "structearly__go_1_1message__writer__for__thread.html#a15cb6646528b9f70e44e3babc0c311a5", null ],
    [ "hdc_", "structearly__go_1_1message__writer__for__thread.html#aea6d9b63ef2773f10c8832fee36393ac", null ],
    [ "hfont_", "structearly__go_1_1message__writer__for__thread.html#ae21974ca96bd81ed1d34a256fd5b1e81", null ],
    [ "message_", "structearly__go_1_1message__writer__for__thread.html#a5e49df64f7fafa8dacbe6f83cb478091", null ],
    [ "old_font_", "structearly__go_1_1message__writer__for__thread.html#a126c39d796e98d72690b6065f6fce6ef", null ],
    [ "start_point_", "structearly__go_1_1message__writer__for__thread.html#a80e1ae56647787fad19b8bec0709f0fe", null ],
    [ "text_image_", "structearly__go_1_1message__writer__for__thread.html#ac8b3d102cc41c0e9316448d10fdf6776", null ],
    [ "text_metric_", "structearly__go_1_1message__writer__for__thread.html#acda2f6a686811b53300b88a5e2b7564d", null ]
];