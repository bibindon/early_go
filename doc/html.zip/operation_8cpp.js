var operation_8cpp =
[
    [ "set_state", "operation_8cpp.html#aa0c452ae3adb07b0109d19a9d86eef65", null ]
];