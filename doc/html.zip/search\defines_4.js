var searchData=
[
  ['malloc_5fcrt',['malloc_crt',['../stdafx_8hpp.html#a5b4d13f44d9b3b72f1002e3173423f4a',1,'stdafx.hpp']]],
  ['memory_5fleaks',['MEMORY_LEAKS',['../stdafx_8hpp.html#a8409bc062ec8d7b24c3a6a7832c90a2f',1,'stdafx.hpp']]]
];
