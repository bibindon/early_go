var stdafx_8hpp =
[
    [ "_aligned_malloc_crt", "stdafx_8hpp.html#a03118e1723dcf8821cfba342536d0f39", null ],
    [ "BOOST_CONFIG_SUPPRESS_OUTDATED_MESSAGE", "stdafx_8hpp.html#ad3ed955dcadeef6452e2d32bc8c9aa08", null ],
    [ "D3D_DEBUG_INFO", "stdafx_8hpp.html#adf7c0abb93c558aa1735e024103b7fbd", null ],
    [ "malloc_crt", "stdafx_8hpp.html#a5b4d13f44d9b3b72f1002e3173423f4a", null ],
    [ "new_crt", "stdafx_8hpp.html#a4bad8e1625d664cb030989cb830562c6", null ],
    [ "NOMINMAX", "stdafx_8hpp.html#a9f918755b601cf4bffca775992e6fb90", null ]
];