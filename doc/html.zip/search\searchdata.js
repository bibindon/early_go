var indexSectionsWithContent =
{
  0: "_abcdefgiklmnoprstuw~",
  1: "abcdklmnorst",
  2: "e",
  3: "abceikmors",
  4: "abcdefgilmnorstuw~",
  5: "abcdefgiklmoprstw",
  6: "abgt",
  7: "bcdf",
  8: "bcflnpr",
  9: "_bdimnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros"
};

