var exception_8hpp =
[
    [ "custom_exception", "classearly__go_1_1custom__exception.html", "classearly__go_1_1custom__exception" ],
    [ "THROW_WITH_TRACE", "exception_8hpp.html#a9ef235025976be5be0cf45f2744c5f08", null ],
    [ "additional_info", "exception_8hpp.html#a61c37d01fd4fd843c978159690c32246", null ],
    [ "traced", "exception_8hpp.html#acbc771eb67017c3b964759cc40f12366", null ],
    [ "exception_reserve", "exception_8hpp.html#a2c46f67a4d4c75ffa187df9351d3188f", null ]
];