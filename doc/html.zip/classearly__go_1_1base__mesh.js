var classearly__go_1_1base__mesh =
[
    [ "dynamic_texture", "structearly__go_1_1base__mesh_1_1dynamic__texture.html", "structearly__go_1_1base__mesh_1_1dynamic__texture" ],
    [ "combine_type", "classearly__go_1_1base__mesh.html#a5899136d9e11c901e5b5a433a7a0cb97", [
      [ "NORMAL", "classearly__go_1_1base__mesh.html#a5899136d9e11c901e5b5a433a7a0cb97a1e23852820b9154316c7c06e2b7ba051", null ]
    ] ],
    [ "base_mesh", "classearly__go_1_1base__mesh.html#acb70563686d6e5ca8773d4c6b2c2eeb2", null ],
    [ "render", "classearly__go_1_1base__mesh.html#a0b382107c03395d557215fdf24035d9a", null ],
    [ "set_animation", "classearly__go_1_1base__mesh.html#a37552897277316827d568401cc734af2", null ],
    [ "set_animation_config", "classearly__go_1_1base__mesh.html#aebeefc427f74ffe22dc5b310e602bb69", null ],
    [ "set_default_animation", "classearly__go_1_1base__mesh.html#afee8b77ad510ae3a9790f92b8df93867", null ],
    [ "set_dynamic_message", "classearly__go_1_1base__mesh.html#a192c558cd658107bbc55dcd65c0b9471", null ],
    [ "set_dynamic_message_color", "classearly__go_1_1base__mesh.html#ae2015539723a2ef972b3054da4ca857b", null ],
    [ "set_dynamic_texture", "classearly__go_1_1base__mesh.html#a46670e92e0413d3dfa35bef8d0bd600f", null ],
    [ "set_dynamic_texture_opacity", "classearly__go_1_1base__mesh.html#a6850368034188043e33a8153b86f6bcd", null ],
    [ "set_dynamic_texture_position", "classearly__go_1_1base__mesh.html#a7f02946fe49fb7405c0f755bb82c12a6", null ],
    [ "set_position", "classearly__go_1_1base__mesh.html#aedca63c7a13b664775ab792ea9a6bc74", null ],
    [ "set_rotation", "classearly__go_1_1base__mesh.html#a563faf3b21977959203d76a840f67b2a", null ],
    [ "set_shake_texture", "classearly__go_1_1base__mesh.html#a9114312941109da3d8a0b4257629c843", null ],
    [ "animation_strategy_", "classearly__go_1_1base__mesh.html#ae19fcecea8e71a9fdbd3dcc4322b26a9", null ],
    [ "brightness_handle_", "classearly__go_1_1base__mesh.html#a607c352ee94c49ea776a336fcbcaf3ec", null ],
    [ "d3d_device_", "classearly__go_1_1base__mesh.html#ad36283a56c00c3a9c7539dbb8f56c5c6", null ],
    [ "diffuse_handle_", "classearly__go_1_1base__mesh.html#a673b931fba215465e4c86679e4ea9d04", null ],
    [ "dynamic_texture_", "classearly__go_1_1base__mesh.html#a99646244b757bbc32ee1b65ee1ce0328", null ],
    [ "effect_", "classearly__go_1_1base__mesh.html#a762e1bd8dae58c19f0c2045f6f74567f", null ],
    [ "light_normal_handle_", "classearly__go_1_1base__mesh.html#ad21fb4a3bd5762c6e5dad40c98365a73", null ],
    [ "mesh_texture_handle_", "classearly__go_1_1base__mesh.html#acfd45628cc6b25b7a6d6c5b322dcfb65", null ],
    [ "position_", "classearly__go_1_1base__mesh.html#abd18b47aa181c816a54cd79a9106edaa", null ],
    [ "rotation_", "classearly__go_1_1base__mesh.html#a6ccbb502ca825971a890ea8935ee8f10", null ],
    [ "texture_handle_", "classearly__go_1_1base__mesh.html#aacb2350fc34a9aa4674ed10fcb4f9d8d", null ],
    [ "texture_opacity_handle_", "classearly__go_1_1base__mesh.html#aaa975aabde46e227c295927e4e534447", null ],
    [ "texture_position_handle_", "classearly__go_1_1base__mesh.html#a5a27bd524de73674a94a4ada08a6e4bd", null ]
];