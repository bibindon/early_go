var searchData=
[
  ['additional_5finfo',['additional_info',['../namespaceearly__go.html#a61c37d01fd4fd843c978159690c32246',1,'early_go']]]
];
