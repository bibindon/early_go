var error__dialog_8hpp =
[
    [ "error_dialog_procedure", "error__dialog_8hpp.html#a1124232771dd3b63bb88dd7ed7d9f9c7", null ],
    [ "show_error_dialog", "error__dialog_8hpp.html#ac3f7a6bde4438e86645ca178f05b98e1", null ]
];