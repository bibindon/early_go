var inline__macro_8hpp =
[
    [ "custom_deleter", "structearly__go_1_1custom__deleter.html", "structearly__go_1_1custom__deleter" ],
    [ "log_liner", "structearly__go_1_1log__liner.html", "structearly__go_1_1log__liner" ],
    [ "get_resource", "inline__macro_8hpp.html#a8617ea0932a5c9db945e332a8227371d", null ],
    [ "safe_delete", "inline__macro_8hpp.html#a913679397f27a3467c80f4c560c198dc", null ],
    [ "safe_delete_array", "inline__macro_8hpp.html#ab37df7eddb20306263a333ff7698fb0d", null ],
    [ "safe_release", "inline__macro_8hpp.html#acc373eee9ff02d1cc0495e9dd9a7318b", null ]
];