var operation_8cpp =
[
    [ "set_state", "operation_8cpp.html#aa6f09e066e796db9a67ad93c178e2a6e", null ]
];