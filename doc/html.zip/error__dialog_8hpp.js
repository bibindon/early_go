var error__dialog_8hpp =
[
    [ "error_dialog_procedure", "error__dialog_8hpp.html#af67be386b29cfe59f8e57cc24570b49b", null ],
    [ "error_dialog_procedure", "error__dialog_8hpp.html#a5c70837b6015bceea909a6df8b44707d", null ],
    [ "show_error_dialog", "error__dialog_8hpp.html#a7301a9cc6c8bb7aed6cf48d0ccfbacd9", null ]
];