var classearly__go_1_1novel =
[
    [ "get_is_novel_part", "classearly__go_1_1novel.html#a524269af64f87f07469e638fb9e1470c", null ],
    [ "operator()", "classearly__go_1_1novel.html#ac4cf3cb29f9150e419ec56562104349c", null ],
    [ "set_is_novel_part", "classearly__go_1_1novel.html#a9974083c2f4b293ab4cea2898ad9c6c9", null ],
    [ "lua_state_", "classearly__go_1_1novel.html#a69efd38d225d5469458c4116f39f6e39", null ]
];