var searchData=
[
  ['window_5fheight',['WINDOW_HEIGHT',['../structearly__go_1_1constants.html#a231da0f0a17b1565c0c82b1fc24cb75b',1,'early_go::constants']]],
  ['window_5fwidth',['WINDOW_WIDTH',['../structearly__go_1_1constants.html#af3a6e0cac11d5836e5bd111d073afd42',1,'early_go::constants']]]
];
