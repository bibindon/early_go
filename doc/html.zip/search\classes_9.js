var searchData=
[
  ['operation',['operation',['../classearly__go_1_1operation.html',1,'early_go']]]
];
