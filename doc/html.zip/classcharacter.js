var classcharacter =
[
    [ "character", "classcharacter.html#aad29ae0a639f4f0b624222296df4534c", null ],
    [ "~character", "classcharacter.html#aa0eaa386a09844f41ed246d87f59cbe1", null ]
];