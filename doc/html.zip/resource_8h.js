var resource_8h =
[
    [ "IDC_EDIT1", "resource_8h.html#ad123446cb35c803caf42a339fc842813", null ],
    [ "IDD_DIALOG1", "resource_8h.html#ab794ba40dfcf73e112ade9f50c4565da", null ],
    [ "IDI_ICON1", "resource_8h.html#a455fef2a9349aae3af8ef8f24f6fc9d8", null ],
    [ "IDI_ICON2", "resource_8h.html#ab646dec1c42c0f4e7960e71dba9957b2", null ]
];