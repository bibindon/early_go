var text_8cpp =
[
    [ "add_text", "text_8cpp.html#a1fb4b1cbe71a5aea707d7aed279b1940", null ]
];