var searchData=
[
  ['error_5fdialog_5fprocedure',['error_dialog_procedure',['../namespaceearly__go.html#af67be386b29cfe59f8e57cc24570b49b',1,'early_go::error_dialog_procedure(::HWND, UINT, WPARAM, LPARAM)'],['../namespaceearly__go.html#a5c70837b6015bceea909a6df8b44707d',1,'early_go::error_dialog_procedure(HWND hwnd, UINT msg, WPARAM wparam, LPARAM)']]]
];
