var searchData=
[
  ['text_2ecpp',['text.cpp',['../text_8cpp.html',1,'']]],
  ['text_2ehpp',['text.hpp',['../text_8hpp.html',1,'']]]
];
