var operation_8hpp =
[
    [ "operation", "classearly__go_1_1operation.html", "classearly__go_1_1operation" ],
    [ "interface", "operation_8hpp.html#a8f8bdbe5685d2ab60ca313c61017b92a", null ],
    [ "BOOST_TYPE_ERASURE_MEMBER", "operation_8hpp.html#a0428cea7b7b53748d467e3b0664f6aab", null ],
    [ "cancel", "operation_8hpp.html#a374c6aa12d8fffac49e1ea4b748345ed", null ]
];