var text_8hpp =
[
    [ "message_writer", "structearly__go_1_1message__writer.html", "structearly__go_1_1message__writer" ],
    [ "add_text", "text_8hpp.html#a3e75d7941ce57bc9e8aea00514ec6557", null ]
];