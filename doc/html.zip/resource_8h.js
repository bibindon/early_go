var resource_8h =
[
    [ "IDC_EDIT1", "resource_8h.html#ad123446cb35c803caf42a339fc842813", null ],
    [ "IDD_DIALOG1", "resource_8h.html#ab794ba40dfcf73e112ade9f50c4565da", null ]
];