var text_8cpp =
[
    [ "add_text", "text_8cpp.html#a548acc7c87b68bb19a1a9b1504b9e53e", null ]
];