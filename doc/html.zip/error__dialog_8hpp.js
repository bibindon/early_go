var error__dialog_8hpp =
[
    [ "error_dialog_procedure", "error__dialog_8hpp.html#a3b7521e7796f3a794627423bb31ccfa9", null ],
    [ "show_error_dialog", "error__dialog_8hpp.html#ac3f7a6bde4438e86645ca178f05b98e1", null ]
];