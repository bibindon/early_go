var text_8hpp =
[
    [ "message_writer", "structearly__go_1_1message__writer.html", "structearly__go_1_1message__writer" ],
    [ "add_text", "text_8hpp.html#a548acc7c87b68bb19a1a9b1504b9e53e", null ]
];