var text_8cpp =
[
    [ "add_text", "text_8cpp.html#ac07fedd0a9c471595f753513af33e35e", null ]
];