var searchData=
[
  ['new_5fcrt',['new_crt',['../stdafx_8hpp.html#a4bad8e1625d664cb030989cb830562c6',1,'stdafx.hpp']]]
];
