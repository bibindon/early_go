var searchData=
[
  ['novel_2ecpp',['novel.cpp',['../novel_8cpp.html',1,'']]],
  ['novel_2ehpp',['novel.hpp',['../novel_8hpp.html',1,'']]]
];
