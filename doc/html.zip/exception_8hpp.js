var exception_8hpp =
[
    [ "custom_exception", "classearly__go_1_1custom__exception.html", "classearly__go_1_1custom__exception" ],
    [ "additional_info", "exception_8hpp.html#a61c37d01fd4fd843c978159690c32246", null ]
];