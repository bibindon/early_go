var files_dup =
[
    [ "animation_mesh.cpp", "animation__mesh_8cpp.html", null ],
    [ "animation_mesh.hpp", "animation__mesh_8hpp.html", [
      [ "animation_mesh", "classearly__go_1_1animation__mesh.html", "classearly__go_1_1animation__mesh" ]
    ] ],
    [ "animation_mesh_allocator.cpp", "animation__mesh__allocator_8cpp.html", null ],
    [ "animation_mesh_allocator.hpp", "animation__mesh__allocator_8hpp.html", [
      [ "animation_mesh_frame", "structearly__go_1_1animation__mesh__frame.html", "structearly__go_1_1animation__mesh__frame" ],
      [ "animation_mesh_container", "structearly__go_1_1animation__mesh__container.html", "structearly__go_1_1animation__mesh__container" ],
      [ "animation_mesh_allocator", "classearly__go_1_1animation__mesh__allocator.html", "classearly__go_1_1animation__mesh__allocator" ]
    ] ],
    [ "animation_strategy.hpp", "animation__strategy_8hpp.html", [
      [ "animation_strategy", "classearly__go_1_1animation__strategy.html", "classearly__go_1_1animation__strategy" ],
      [ "no_animation", "classearly__go_1_1no__animation.html", "classearly__go_1_1no__animation" ],
      [ "normal_animation", "classearly__go_1_1normal__animation.html", "classearly__go_1_1normal__animation" ]
    ] ],
    [ "base_mesh.cpp", "base__mesh_8cpp.html", null ],
    [ "base_mesh.hpp", "base__mesh_8hpp.html", [
      [ "base_mesh", "classearly__go_1_1base__mesh.html", "classearly__go_1_1base__mesh" ],
      [ "dynamic_texture", "structearly__go_1_1base__mesh_1_1dynamic__texture.html", "structearly__go_1_1base__mesh_1_1dynamic__texture" ],
      [ "text_message_writer", "structearly__go_1_1base__mesh_1_1dynamic__texture_1_1text__message__writer.html", "structearly__go_1_1base__mesh_1_1dynamic__texture_1_1text__message__writer" ]
    ] ],
    [ "basic_window.cpp", "basic__window_8cpp.html", null ],
    [ "basic_window.hpp", "basic__window_8hpp.html", [
      [ "basic_window", "classearly__go_1_1basic__window.html", "classearly__go_1_1basic__window" ],
      [ "render_string_object", "structearly__go_1_1basic__window_1_1render__string__object.html", null ]
    ] ],
    [ "camera.cpp", "camera_8cpp.html", null ],
    [ "camera.hpp", "camera_8hpp.html", [
      [ "camera", "classearly__go_1_1camera.html", "classearly__go_1_1camera" ]
    ] ],
    [ "character.cpp", "character_8cpp.html", null ],
    [ "character.hpp", "character_8hpp.html", [
      [ "character", "classearly__go_1_1character.html", "classearly__go_1_1character" ]
    ] ],
    [ "constants.cpp", "constants_8cpp.html", null ],
    [ "constants.hpp", "constants_8hpp.html", [
      [ "constants", "structearly__go_1_1constants.html", null ]
    ] ],
    [ "error_dialog.hpp", "error__dialog_8hpp.html", "error__dialog_8hpp" ],
    [ "exception.hpp", "exception_8hpp.html", "exception_8hpp" ],
    [ "inline_macro.hpp", "inline__macro_8hpp.html", "inline__macro_8hpp" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mesh.cpp", "mesh_8cpp.html", null ],
    [ "mesh.hpp", "mesh_8hpp.html", [
      [ "mesh", "classearly__go_1_1mesh.html", "classearly__go_1_1mesh" ]
    ] ],
    [ "resource.h", "resource_8h.html", "resource_8h" ],
    [ "skinned_animation_mesh.cpp", "skinned__animation__mesh_8cpp.html", null ],
    [ "skinned_animation_mesh.hpp", "skinned__animation__mesh_8hpp.html", [
      [ "skinned_animation_mesh", "classearly__go_1_1skinned__animation__mesh.html", "classearly__go_1_1skinned__animation__mesh" ]
    ] ],
    [ "skinned_animation_mesh_allocator.cpp", "skinned__animation__mesh__allocator_8cpp.html", null ],
    [ "skinned_animation_mesh_allocator.hpp", "skinned__animation__mesh__allocator_8hpp.html", [
      [ "skinned_animation_mesh_frame", "structearly__go_1_1skinned__animation__mesh__frame.html", "structearly__go_1_1skinned__animation__mesh__frame" ],
      [ "skinned_animation_mesh_container", "structearly__go_1_1skinned__animation__mesh__container.html", "structearly__go_1_1skinned__animation__mesh__container" ],
      [ "skinned_animation_mesh_allocator", "classearly__go_1_1skinned__animation__mesh__allocator.html", "classearly__go_1_1skinned__animation__mesh__allocator" ]
    ] ],
    [ "stdafx.cpp", "stdafx_8cpp.html", null ],
    [ "stdafx.hpp", "stdafx_8hpp.html", "stdafx_8hpp" ]
];