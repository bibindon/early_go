var searchData=
[
  ['render_5fstring_5fobject',['render_string_object',['../structearly__go_1_1basic__window_1_1render__string__object.html',1,'early_go::basic_window']]],
  ['rotate',['rotate',['../structearly__go_1_1character_1_1rotate.html',1,'early_go::character']]]
];
