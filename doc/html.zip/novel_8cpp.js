var novel_8cpp =
[
    [ "co", "novel_8cpp.html#ac70643f4363123ea503309424709c30d", null ]
];