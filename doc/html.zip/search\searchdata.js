var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvw~",
  1: "abcdlmnrst",
  2: "e",
  3: "abceimrs",
  4: "abcdgilmnoprstw~",
  5: "acdefhklmpstuvw",
  6: "a",
  7: "c",
  8: "n",
  9: "_bdimn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros"
};

