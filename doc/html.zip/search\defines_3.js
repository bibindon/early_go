var searchData=
[
  ['idc_5fedit1',['IDC_EDIT1',['../resource_8h.html#ad123446cb35c803caf42a339fc842813',1,'resource.h']]],
  ['idd_5fdialog1',['IDD_DIALOG1',['../resource_8h.html#ab794ba40dfcf73e112ade9f50c4565da',1,'resource.h']]]
];
