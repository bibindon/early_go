var structearly__go_1_1message__writer__for__thread =
[
    [ "message_writer_for_thread", "structearly__go_1_1message__writer__for__thread.html#aa98547a615fb05621949ee50dcaea1c4", null ],
    [ "~message_writer_for_thread", "structearly__go_1_1message__writer__for__thread.html#a62fc5237641b1dffa849ba0780d6f50b", null ],
    [ "add_text", "structearly__go_1_1message__writer__for__thread.html#a29aa2b6bff39fa70085947b93a54f9e9", null ],
    [ "write_one_character", "structearly__go_1_1message__writer__for__thread.html#ac75d7fe6d04620a2b9c08574e287a876", null ],
    [ "canvas_size_", "structearly__go_1_1message__writer__for__thread.html#a5c2e205241c717f209c04b3cfda74cac", null ],
    [ "character_index_", "structearly__go_1_1message__writer__for__thread.html#a29690749486fed9095bb86344dfe157d", null ],
    [ "color_", "structearly__go_1_1message__writer__for__thread.html#a40a74273f1f7af474103df5ec65f65d9", null ],
    [ "font_height_sum_", "structearly__go_1_1message__writer__for__thread.html#ae13a84281b98ec9ce35b62e0cfc67c42", null ],
    [ "font_width_sum_", "structearly__go_1_1message__writer__for__thread.html#af93f0885777f52d811214b06aef854c4", null ],
    [ "hdc_", "structearly__go_1_1message__writer__for__thread.html#a36090a788d7123a1f5444ab87f5985f7", null ],
    [ "hfont_", "structearly__go_1_1message__writer__for__thread.html#a71cca87cf7f836df3ff04b163da3f8d3", null ],
    [ "message_", "structearly__go_1_1message__writer__for__thread.html#a5e49df64f7fafa8dacbe6f83cb478091", null ],
    [ "old_font_", "structearly__go_1_1message__writer__for__thread.html#a2f346baa14f6fc795a9d9b800cd0315e", null ],
    [ "start_point_", "structearly__go_1_1message__writer__for__thread.html#a80e1ae56647787fad19b8bec0709f0fe", null ],
    [ "text_image_", "structearly__go_1_1message__writer__for__thread.html#a058981dc18a2315570ef6c2c95978698", null ],
    [ "text_metric_", "structearly__go_1_1message__writer__for__thread.html#a58119ed2d8e7099f001bb0465b1a4949", null ]
];