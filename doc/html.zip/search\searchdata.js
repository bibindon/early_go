var indexSectionsWithContent =
{
  0: "_abcdefgilmnoprstuw~",
  1: "abcdilmnrst",
  2: "e",
  3: "abceimrs",
  4: "abcdefgimnorstuw~",
  5: "abcdefilmoprstw",
  6: "at",
  7: "cf",
  8: "fn",
  9: "_bdimnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros"
};

